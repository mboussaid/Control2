
let EmailInput = document.getElementById('email_input')
let PasswordInput = document.getElementById('password_input')
let RadioTDI = document.getElementById('radio_tdi')
let RadioTRI = document.getElementById('radio_tri')
let RadioTMI = document.getElementById('radio_tmi')
let AllRadio = document.querySelectorAll("input[type='radio']")
let SelectVilleInput = document.getElementById('ville_input')
let ValidateInput = document.getElementById('validate_input')
let SendInput = document.getElementById('send_input')
let ErrorDiv = document.getElementById('errors');
$(document).ready(()=>{

    const Villes = [   {
        "id": "1",
        "ville": "Aïn Harrouda",
        "region": "6"
      },
      {
        "id": "2",
        "ville": "Ben Yakhlef",
        "region": "6"
      },
      {
        "id": "3",
        "ville": "Bouskoura",
        "region": "6"
      },
      {
        "id": "4",
        "ville": "Casablanca",
        "region": "6"
      },
      {
        "id": "5",
        "ville": "Médiouna",
        "region": "6"
      },
      {
        "id": "6",
        "ville": "Mohammadia",
        "region": "6"
      },
      {
        "id": "7",
        "ville": "Tit Mellil",
        "region": "6"
      },
      {
        "id": "8",
        "ville": "Ben Yakhlef",
        "region": "6"
      }]



///RegExpressions
     let RegExpEmail = /^\w+@\w+.\w+$/;
     let RegExpPassword = /^\d{2,}\w{6,}$/
    //   Inputs


   /// Ajouter Les Villes
    Villes.forEach(ville=>{
        let option = new Option(ville.ville,ville.id)
        SelectVilleInput.appendChild(option)
    })

  

    ValidateInput.addEventListener('click',()=>{
        let ERRORS = []
        let valid = true;
         let Email = EmailInput.value;
         let Password= PasswordInput.value
        if(!RegExpEmail.test(Email)){valid = false ; ERRORS.push('Email est invalid') }
        if(!RegExpPassword.test(Password)){valid = false;ERRORS.push('password est invalid') }
        let checked = false;
        AllRadio.forEach(radio=>{
            if(radio.checked){
                checked = true
            }
        })
    
        if(!RadioTRI.checked && !RadioTRI.checked && !RadioTMI.checked){
            valid = false;
            ERRORS.push('Selectioner une filier')
            
        }
      

        if(document.getElementById('ville_input').value == "error"){valid = false;
            ERRORS.push('Selectioner une ville')
        }
        if(valid){
            alert('valid')
        }else{
           
            // document.getElementById('d1').innerHTML = `dddddddd`
         
            $('#errors').html('')
            ERRORS.forEach(error=>{
                let li = document.createElement('li')
                li.textContent = error;
                ErrorDiv.appendChild(li)
            })
            $('#errors').animate({marginLeft:'+10px'},200).animate({marginLeft:'-20px'},200).animate({marginLeft:'0px'},200)
           
        }
        

    })
SendInput.addEventListener('click',()=>{
    let url = "http://localhost:81/tp/insertDatabase.php";
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange=()=>{
        if(xhr.status == 200 && xhr.readyState == 4){
            $('#resp').html(xhr.responseText).animate({marginLeft:'+10px'},200).animate({marginLeft:'-20px'},200).animate({marginLeft:'0px'},200)

           
        }
    }
    let filier = null ;
    if(RadioTRI.checked){filier = 'TRI'}
    if(RadioTDI.checked){filier = 'TDI'}
    if(RadioTMI.checked){filier = 'TMI'}
    let email = EmailInput.value
    let password = PasswordInput.value
    let ville = SelectVilleInput.value
    xhr.open('GET',`${url}?email=${email}&password=${password}&filier=${filier}&ville=${ville}`);
    xhr.send()
})
})